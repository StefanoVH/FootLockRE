let form = document.getElementById("subscriptionForm")

function validateName(name){
    return(
        name.length > 0
    )
}

let emailErrorMessage = [
    "Email must be filled",
    "Email must contain @",
    "Email must contain (gmail.com, yahoo.co.id, etc)"
]

function validateEmail(email){
    let split = email.split("@")

    if(email.length <= 0){
        return 0
    }
    
    if(split.length == 1){
        return 1
    }

    let checkDot = split[split.length - 1]
    let checkDotSplit = checkDot.split(".")
    if(checkDotSplit.length == 1){
        return 2
    }

    

    return -1
}

function validatePhone(phone){
    return(
        phone.length > 0
    )
}

function validateCountry(country){
    if(country.selectedIndex == 0){
        return false
    }
    return true
}

let error = document.getElementById("error");
function showError(message){
    error.style.display = 'block'
    error.innerHTML = message
}

function clearError(){
    error.style.display = "none"
}

function formSubmit(){
    let name = document.getElementById("name")
    if(!validateName(name.value)){
        showError("Name must be filled")
        return
    }

    let email = document.getElementById("email")
    let checkEmail = validateEmail(email.value)
    if(checkEmail != -1){
        showError(emailErrorMessage[checkEmail])
        return
    }

    let phone = document.getElementById("phone")
    if(!validatePhone(phone.value)){
        showError("Phone Number must be filled")
        return
    }

    let countries = document.getElementById("country")
    if(!validateCountry(countries)){
        showError("Please select a country")
        return
    }
    let country = countries.options[countries.selectedIndex].value

    let checkBox = document.getElementById("agreeTerms")
    if(!checkBox.checked){
        showError("Please agree to Terms and Conditions")
        return
    }

    clearError()
    alert("Form succesfully submitted")
    console.log(name.value)
    console.log(email.value)
    console.log(phone.value)
    console.log(country)
    console.log(checkBox.value)

    document.getElementById("subscriptionForm").reset()
}

form.addEventListener("submit", (e)=>{
    e.preventDefault()
    formSubmit()
})